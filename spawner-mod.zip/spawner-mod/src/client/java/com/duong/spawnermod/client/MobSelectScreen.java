package com.duong.spawnermod.client;

import com.duong.spawnermod.network.ConfirmMobSelectionPayload;
import com.duong.spawnermod.spawner.SpawnableMob;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Client-only screen shown after /ok. Lists the mob ids the server said are
 * available (already biome-filtered) as buttons with the mob's spawn egg
 * icon. Clicking a mob highlights it as selected; clicking the OK button at
 * the bottom sends ConfirmMobSelectionPayload to the server and closes the
 * screen. This screen does not talk to the world/biome data directly - it
 * only ever shows what the server already decided was valid.
 */
public class MobSelectScreen extends Screen {

    private static final int ROW_HEIGHT = 24;
    private static final int BUTTON_WIDTH = 200;

    private final List<SpawnableMob> options;
    private final java.util.Map<SpawnableMob, ButtonWidget> mobButtons = new java.util.HashMap<>();
    private SpawnableMob selected;
    private ButtonWidget confirmButton;

    public MobSelectScreen(List<String> availableMobIds) {
        super(Text.literal("Chọn quái để spawn"));
        this.options = availableMobIds.stream()
                .map(id -> {
                    try {
                        return SpawnableMob.valueOf(id);
                    } catch (IllegalArgumentException e) {
                        return null;
                    }
                })
                .filter(m -> m != null)
                .toList();
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int startY = this.height / 2 - (options.size() * ROW_HEIGHT) / 2;

        for (int i = 0; i < options.size(); i++) {
            SpawnableMob mob = options.get(i);
            int y = startY + i * ROW_HEIGHT;

            ButtonWidget mobButton = ButtonWidget.builder(
                    buttonLabel(mob, false),
                    button -> selectMob(mob)
            ).dimensions(centerX - BUTTON_WIDTH / 2, y, BUTTON_WIDTH, ROW_HEIGHT - 4).build();

            mobButtons.put(mob, mobButton);
            this.addDrawableChild(mobButton);
        }

        int confirmY = startY + options.size() * ROW_HEIGHT + 20;
        this.confirmButton = ButtonWidget.builder(
                Text.literal("OK"),
                button -> confirmAndClose()
        ).dimensions(centerX - 50, confirmY, 100, 20).build();
        this.confirmButton.active = false;
        this.addDrawableChild(this.confirmButton);

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Hủy"),
                button -> this.close()
        ).dimensions(centerX + 60, confirmY, 60, 20).build());
    }

    private Text buttonLabel(SpawnableMob mob, boolean isSelected) {
        return isSelected
                ? Text.literal(">> " + mob.displayName + " <<").formatted(net.minecraft.util.Formatting.GREEN, net.minecraft.util.Formatting.BOLD)
                : Text.literal(mob.displayName);
    }

    private void selectMob(SpawnableMob mob) {
        // Reset every button back to its plain label first, then highlight the one just picked.
        for (var entry : mobButtons.entrySet()) {
            entry.getValue().setMessage(buttonLabel(entry.getKey(), entry.getKey() == mob));
        }

        this.selected = mob;
        this.confirmButton.active = true;
    }

    private void confirmAndClose() {
        if (selected == null) {
            return;
        }
        ClientPlayNetworking.send(new ConfirmMobSelectionPayload(selected.name()));
        this.close();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(
                this.textRenderer,
                this.title,
                this.width / 2,
                this.height / 2 - (options.size() * ROW_HEIGHT) / 2 - 20,
                0xFFFFFF
        );

        int confirmY = this.height / 2 - (options.size() * ROW_HEIGHT) / 2 + options.size() * ROW_HEIGHT + 20;

        if (selected != null) {
            Text statusText = Text.literal("Đã chọn: " + selected.displayName)
                    .formatted(net.minecraft.util.Formatting.GREEN);
            context.drawCenteredTextWithShadow(
                    this.textRenderer,
                    statusText,
                    this.width / 2,
                    confirmY - 12,
                    0xFFFFFF
            );

            ItemStack egg = new ItemStack(selected.spawnEggIcon);
            context.drawItem(egg, this.width / 2 - 8, confirmY - 32);
        } else {
            context.drawCenteredTextWithShadow(
                    this.textRenderer,
                    Text.literal("Chưa chọn quái nào").formatted(net.minecraft.util.Formatting.GRAY),
                    this.width / 2,
                    confirmY - 12,
                    0xFFFFFF
            );
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
