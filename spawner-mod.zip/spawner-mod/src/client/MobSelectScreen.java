package com.duong.spawnermod.client;

import com.duong.spawnermod.network.ConfirmMobSelectionPayload;
import com.duong.spawnermod.spawner.SpawnableMob;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

import java.util.List;

public class MobSelectScreen extends Screen {

    private static final int ROW_HEIGHT = 24;
    private static final int BUTTON_WIDTH = 200;

    private final List<SpawnableMob> options;
    private SpawnableMob selected;
    private ButtonWidget confirmButton;

    public MobSelectScreen(List<String> availableMobIds) {
        super(Text.literal("Chọn quái để spawn"));
        this.options = availableMobIds.stream()
                .map(id -> {
                    try {
                        return SpawnableMob.valueOf(id);
                    } catch (IllegalArgumentException e) {
                        return null;
                    }
                })
                .filter(m -> m != null)
                .toList();
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int startY = this.height / 2 - (options.size() * ROW_HEIGHT) / 2;

        for (int i = 0; i < options.size(); i++) {
            SpawnableMob mob = options.get(i);
            int y = startY + i * ROW_HEIGHT;

            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal(mob.displayName),
                    button -> selectMob(mob)
            ).dimensions(centerX - BUTTON_WIDTH / 2, y, BUTTON_WIDTH, ROW_HEIGHT - 4).build());
        }

        int confirmY = startY + options.size() * ROW_HEIGHT + 10;
        this.confirmButton = ButtonWidget.builder(
                Text.literal("OK"),
                button -> confirmAndClose()
        ).dimensions(centerX - 50, confirmY, 100, 20).build();
        this.confirmButton.active = false;
        this.addDrawableChild(this.confirmButton);

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Hủy"),
                button -> this.close()
        ).dimensions(centerX + 60, confirmY, 60, 20).build());
    }

    private void selectMob(SpawnableMob mob) {
        this.selected = mob;
        this.confirmButton.active = true;
    }

    private void confirmAndClose() {
        if (selected == null) {
            return;
        }
        ClientPlayNetworking.send(new ConfirmMobSelectionPayload(selected.name()));
        this.close();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(
                this.textRenderer,
                this.title,
                this.width / 2,
                this.height / 2 - (options.size() * ROW_HEIGHT) / 2 - 20,
                0xFFFFFF
        );

        if (selected != null) {
            ItemStack egg = new ItemStack(selected.spawnEggIcon);
            context.drawItem(egg, this.width / 2 - 8, this.height - 40);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}