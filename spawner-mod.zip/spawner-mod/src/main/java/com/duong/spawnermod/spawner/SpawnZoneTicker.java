package com.duong.spawnermod.spawner;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Drives the actual spawning for every SpawnZone, once per server tick.
 *
 * Per zone: a random cooldown (in ticks) counts down; once it hits zero, a
 * random amount (1-3) of mobs are spawned, each one an independently random
 * pick from that zone's mob list, at a random valid position inside the
 * zone's box. A new random cooldown is then rolled for the next round.
 */
public final class SpawnZoneTicker {

    // Cooldown range in ticks: 20 ticks = 1 second. This gives spawns roughly
    // every 4-12 seconds per zone, randomized each round as requested.
    private static final int MIN_COOLDOWN_TICKS = 80;
    private static final int MAX_COOLDOWN_TICKS = 240;

    private static final int MIN_MOBS_PER_ROUND = 1;
    private static final int MAX_MOBS_PER_ROUND = 3;

    private static final int MAX_PLACEMENT_ATTEMPTS_PER_MOB = 10;

    private static final Map<UUID, Integer> cooldowns = new HashMap<>();
    private static final Random random = Random.create();

    private SpawnZoneTicker() {
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(SpawnZoneTicker::onServerTick);
    }

    private static void onServerTick(MinecraftServer server) {
        SpawnZoneState state = SpawnZoneState.get(server);
        List<SpawnZone> zones = state.getZones();

        if (zones.isEmpty()) {
            return;
        }

        for (SpawnZone zone : zones) {
            int remaining = cooldowns.getOrDefault(zone.id(), rollCooldown());

            if (remaining <= 0) {
                trySpawnRound(server, zone);
                cooldowns.put(zone.id(), rollCooldown());
            } else {
                cooldowns.put(zone.id(), remaining - 1);
            }
        }
    }

    private static int rollCooldown() {
        return MIN_COOLDOWN_TICKS + random.nextInt(MAX_COOLDOWN_TICKS - MIN_COOLDOWN_TICKS + 1);
    }

    private static void trySpawnRound(MinecraftServer server, SpawnZone zone) {
        ServerWorld world = server.getWorld(zone.dimension());
        if (world == null) {
            return; // dimension not loaded/valid - skip this round silently
        }

        List<SpawnableMob> mobs = zone.resolveMobs();
        if (mobs.isEmpty()) {
            return;
        }

        int amount = MIN_MOBS_PER_ROUND + random.nextInt(MAX_MOBS_PER_ROUND - MIN_MOBS_PER_ROUND + 1);

        for (int i = 0; i < amount; i++) {
            SpawnableMob mob = mobs.get(random.nextInt(mobs.size()));
            spawnOne(world, zone, mob);
        }
    }

    private static void spawnOne(ServerWorld world, SpawnZone zone, SpawnableMob mob) {
        BlockPos min = zone.min();
        BlockPos max = zone.max();

        for (int attempt = 0; attempt < MAX_PLACEMENT_ATTEMPTS_PER_MOB; attempt++) {
            int x = min.getX() + random.nextInt(max.getX() - min.getX() + 1);
            int y = min.getY() + random.nextInt(max.getY() - min.getY() + 1);
            int z = min.getZ() + random.nextInt(max.getZ() - min.getZ() + 1);
            BlockPos pos = new BlockPos(x, y, z);

            if (!SpawnPositionValidator.isValidSpawnPosition(world, pos)) {
                continue;
            }

            @SuppressWarnings("unchecked")
            EntityType<Entity> type = (EntityType<Entity>) mob.entityType;

            Entity entity = type.spawn(world, pos, SpawnReason.SPAWN_ITEM_USE);
            if (entity != null) {
                return; // successfully placed this one - stop trying more positions
            }
        }
        // If every attempt failed (no valid ground found in the box), just skip
        // this mob for this round rather than forcing a bad spawn.
    }
}
