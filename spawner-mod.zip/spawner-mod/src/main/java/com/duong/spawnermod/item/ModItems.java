package com.duong.spawnermod.item;

import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public final class ModItems {

    public static final RegistryKey<Item> SPAWNER_WAND_KEY =
            RegistryKey.of(RegistryKeys.ITEM, Identifier.of("spawnermod", "spawner_wand"));

    public static final Item SPAWNER_WAND = new SpawnerWandItem(
            new Item.Settings()
                    .registryKey(SPAWNER_WAND_KEY)
                    .maxCount(1)
    );

    private ModItems() {
    }

    public static void initialize() {
        Registry.register(Registries.ITEM, SPAWNER_WAND_KEY, SPAWNER_WAND);

        net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS)
                .register(entries -> entries.add(SPAWNER_WAND));
    }
}
