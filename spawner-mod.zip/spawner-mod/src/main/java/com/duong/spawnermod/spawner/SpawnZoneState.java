package com.duong.spawnermod.spawner;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateType;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Stores every SpawnZone that has been confirmed, persisted to disk so zones
 * survive server restarts. One instance per world (stored via the overworld,
 * since zones can reference any dimension through SpawnZone.dimension()).
 */
public class SpawnZoneState extends PersistentState {

    private final List<SpawnZone> zones = new ArrayList<>();

    private static final Codec<SpawnZoneState> CODEC = SpawnZone.CODEC.listOf().xmap(
            list -> {
                SpawnZoneState state = new SpawnZoneState();
                state.zones.addAll(list);
                return state;
            },
            state -> state.zones
    );

    public static final PersistentStateType<SpawnZoneState> TYPE = new PersistentStateType<>(
            "spawnermod_spawn_zones",
            SpawnZoneState::new,
            context -> CODEC,
            null
    );

    public static SpawnZoneState get(MinecraftServer server) {
        ServerWorld overworld = server.getWorld(World.OVERWORLD);
        return overworld.getPersistentStateManager().getOrCreate(TYPE);
    }

    public List<SpawnZone> getZones() {
        return List.copyOf(zones);
    }

    public void addZone(SpawnZone zone) {
        zones.add(zone);
        markDirty();
    }

    public boolean removeZone(UUID id) {
        boolean removed = zones.removeIf(z -> z.id().equals(id));
        if (removed) {
            markDirty();
        }
        return removed;
    }
}
