package com.duong.spawnermod.spawner;

import net.minecraft.entity.EntityType;
import net.minecraft.item.Items;
import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.biome.BiomeKeys;

import java.util.List;

public enum SpawnableMob {

    ZOMBIE(EntityType.ZOMBIE, Items.ZOMBIE_SPAWN_EGG, "Zombie", null),
    ZOMBIE_VILLAGER(EntityType.ZOMBIE_VILLAGER, Items.ZOMBIE_VILLAGER_SPAWN_EGG, "Zombie Villager", null),
    SKELETON(EntityType.SKELETON, Items.SKELETON_SPAWN_EGG, "Skeleton", null),
    CREEPER(EntityType.CREEPER, Items.CREEPER_SPAWN_EGG, "Creeper", null),
    SPIDER(EntityType.SPIDER, Items.SPIDER_SPAWN_EGG, "Spider", null),
    WITCH(EntityType.WITCH, Items.WITCH_SPAWN_EGG, "Witch", null),

    BLAZE(EntityType.BLAZE, Items.BLAZE_SPAWN_EGG, "Blaze",
            BiomeRequirement.of(BiomeKeys.NETHER_WASTES)),
    WITHER_SKELETON(EntityType.WITHER_SKELETON, Items.WITHER_SKELETON_SPAWN_EGG, "Wither Skeleton",
            BiomeRequirement.of(BiomeKeys.SOUL_SAND_VALLEY));

    public final EntityType<?> entityType;
    public final net.minecraft.item.Item spawnEggIcon;
    public final String displayName;
    private final BiomeRequirement biomeRequirement;

    SpawnableMob(EntityType<?> entityType, net.minecraft.item.Item spawnEggIcon, String displayName,
                 BiomeRequirement biomeRequirement) {
        this.entityType = entityType;
        this.spawnEggIcon = spawnEggIcon;
        this.displayName = displayName;
        this.biomeRequirement = biomeRequirement;
    }

    public boolean isAvailableAt(World world, BlockPos pointA) {
        if (biomeRequirement == null) {
            return true;
        }
        return biomeRequirement.isSatisfiedAt(world, pointA);
    }

    public static List<SpawnableMob> all() {
        return List.of(values());
    }
}