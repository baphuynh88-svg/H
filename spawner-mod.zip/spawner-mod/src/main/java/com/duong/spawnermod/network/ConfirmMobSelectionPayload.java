package com.duong.spawnermod.network;

import com.duong.spawnermod.SpawnerMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.List;

/**
 * Sent client -> server when the player clicks OK in the mob-select screen.
 * Carries the chosen mobs' enum names (see SpawnableMob) - the server
 * re-validates everything (selection still complete, biome requirement still
 * satisfied for each mob) rather than trusting the client blindly.
 */
public record ConfirmMobSelectionPayload(List<String> mobIds) implements CustomPayload {

    public static final CustomPayload.Id<ConfirmMobSelectionPayload> ID =
            new CustomPayload.Id<>(Identifier.of(SpawnerMod.MOD_ID, "confirm_mob_selection"));

    public static final PacketCodec<RegistryByteBuf, ConfirmMobSelectionPayload> CODEC =
            PacketCodec.tuple(
                    PacketCodecs.STRING.collect(PacketCodecs.toList()), ConfirmMobSelectionPayload::mobIds,
                    ConfirmMobSelectionPayload::new
            );

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
