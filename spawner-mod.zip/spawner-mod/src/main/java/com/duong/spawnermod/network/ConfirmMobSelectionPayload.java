package com.duong.spawnermod.network;

import com.duong.spawnermod.SpawnerMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record ConfirmMobSelectionPayload(String mobId) implements CustomPayload {

    public static final CustomPayload.Id<ConfirmMobSelectionPayload> ID =
            new CustomPayload.Id<>(Identifier.of(SpawnerMod.MOD_ID, "confirm_mob_selection"));

    public static final PacketCodec<RegistryByteBuf, ConfirmMobSelectionPayload> CODEC =
            PacketCodec.tuple(
                    PacketCodecs.STRING, ConfirmMobSelectionPayload::mobId,
                    ConfirmMobSelectionPayload::new
            );

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}