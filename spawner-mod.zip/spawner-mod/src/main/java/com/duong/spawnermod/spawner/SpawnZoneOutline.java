package com.duong.spawnermod.spawner;

import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Draws a particle outline around a SpawnZone's box, sent only to the
 * requesting player, for a few seconds - so /showzones actually gives a
 * visible box in the world instead of just printing coordinates in chat.
 *
 * Purely visual: does not touch SpawnZoneState or any spawning logic.
 */
public final class SpawnZoneOutline {

    // Spaced roughly every block along each edge so the outline reads
    // clearly without flooding the client with particles on big zones.
    private static final double STEP = 0.5;

    // How many times to repeat the outline burst, spaced a few ticks apart,
    // so it's visible for a few seconds rather than a single instant flash.
    private static final int REPEATS = 5;
    private static final long REPEAT_DELAY_TICKS = 20L; // 1 second apart

    private SpawnZoneOutline() {
    }

    public static void show(World world, SpawnZone zone, ServerPlayerEntity viewer, boolean paused) {
        if (!(world instanceof net.minecraft.server.world.ServerWorld serverWorld)) {
            return;
        }

        var particle = paused ? ParticleTypes.SMOKE : ParticleTypes.HAPPY_VILLAGER;

        for (int i = 0; i < REPEATS; i++) {
            long delayTicks = i * REPEAT_DELAY_TICKS;
            if (delayTicks <= 0) {
                drawOutline(serverWorld, zone, viewer, particle);
            } else {
                OutlineScheduler.runAfter(delayTicks, () -> drawOutline(serverWorld, zone, viewer, particle));
            }
        }
    }

    static void drawOutline(net.minecraft.server.world.ServerWorld world, SpawnZone zone,
                             ServerPlayerEntity viewer, net.minecraft.particle.ParticleEffect particle) {
        BlockPos min = zone.min();
        BlockPos max = zone.max();

        double minX = min.getX();
        double minY = min.getY();
        double minZ = min.getZ();
        double maxX = max.getX() + 1.0;
        double maxY = max.getY() + 1.0;
        double maxZ = max.getZ() + 1.0;

        // The 12 edges of the box, as (start, end) pairs.
        double[][] edges = {
                {minX, minY, minZ, maxX, minY, minZ},
                {maxX, minY, minZ, maxX, minY, maxZ},
                {maxX, minY, maxZ, minX, minY, maxZ},
                {minX, minY, maxZ, minX, minY, minZ},

                {minX, maxY, minZ, maxX, maxY, minZ},
                {maxX, maxY, minZ, maxX, maxY, maxZ},
                {maxX, maxY, maxZ, minX, maxY, maxZ},
                {minX, maxY, maxZ, minX, maxY, minZ},

                {minX, minY, minZ, minX, maxY, minZ},
                {maxX, minY, minZ, maxX, maxY, minZ},
                {maxX, minY, maxZ, maxX, maxY, maxZ},
                {minX, minY, maxZ, minX, maxY, maxZ},
        };

        for (double[] edge : edges) {
            spawnAlongEdge(world, viewer, particle,
                    edge[0], edge[1], edge[2], edge[3], edge[4], edge[5]);
        }
    }

    private static void spawnAlongEdge(net.minecraft.server.world.ServerWorld world, ServerPlayerEntity viewer,
                                        net.minecraft.particle.ParticleEffect particle,
                                        double x1, double y1, double z1, double x2, double y2, double z2) {
        double length = Math.max(Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1)), Math.abs(z2 - z1));
        int steps = Math.max(1, (int) Math.round(length / STEP));

        for (int i = 0; i <= steps; i++) {
            double t = (double) i / steps;
            double x = x1 + (x2 - x1) * t;
            double y = y1 + (y2 - y1) * t;
            double z = z1 + (z2 - z1) * t;
            world.spawnParticles(viewer, particle, false, true, x, y, z, 1, 0, 0, 0, 0);
        }
    }
}
