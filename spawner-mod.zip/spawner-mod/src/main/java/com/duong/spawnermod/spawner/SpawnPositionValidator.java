package com.duong.spawnermod.spawner;

import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.EntityType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

/**
 * Checks whether a block position is valid ground for a mob to spawn/stand on.
 *
 * Rules:
 *  - The block directly below the position must be a FULL solid cube
 *    (this rejects slabs, stairs, trapdoors, carpets, fences, etc. - anything
 *    whose collision shape isn't a complete 1x1x1 block).
 *  - The position itself and the block above it must be empty / non-solid
 *    (enough room for a standard mob to stand - 2 blocks of headroom).
 *  - The position must not be inside a hole below the surrounding terrain in
 *    a way that has no solid floor at all (i.e. the "below" block must exist
 *    and not be air/liquid).
 */
public final class SpawnPositionValidator {

    private SpawnPositionValidator() {
    }

    /**
     * @param world the world to check in
     * @param pos   the position a mob's feet would occupy (not the block below)
     * @return true if a mob could reasonably spawn/stand at this position
     */
    public static boolean isValidSpawnPosition(World world, BlockPos pos) {
        BlockPos below = pos.down();
        BlockState belowState = world.getBlockState(below);

        if (!isFullSolidCube(world, below, belowState)) {
            return false;
        }

        // The feet position and one block above it must be free of solid collision
        // (enough room for a normal-sized mob such as zombie/skeleton/spider to stand).
        if (!isPassable(world, pos)) {
            return false;
        }
        if (!isPassable(world, pos.up())) {
            return false;
        }

        return true;
    }

    /**
     * True if the block's collision shape is a full 1x1x1 cube - rejects slabs,
     * stairs, trapdoors (open or closed), carpets, pressure plates, fences, etc.
     */
    private static boolean isFullSolidCube(World world, BlockPos pos, BlockState state) {
        if (state.isAir()) {
            return false;
        }
        // getCollisionShape gives the actual collision box(es) for this state;
        // isFullCube is true only when that shape is exactly a 1x1x1 block.
        return net.minecraft.block.Block.isShapeFullCube(
                state.getCollisionShape(world, pos, ShapeContext.absent())
        );
    }

    /**
     * True if a mob's bounding box could occupy this position without colliding
     * with the block there (air, or a non-solid block like grass/torch/water is fine
     * for feet space in most vanilla spawn rules - kept simple here as "no collision shape").
     */
    private static boolean isPassable(World world, BlockPos pos) {
        BlockState state = world.getBlockState(pos);
        return state.getCollisionShape(world, pos, ShapeContext.absent()).isEmpty();
    }
}
