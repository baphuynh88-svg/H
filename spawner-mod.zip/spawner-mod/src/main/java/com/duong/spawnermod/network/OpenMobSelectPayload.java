package com.duong.spawnermod.network;

import com.duong.spawnermod.SpawnerMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.List;

public record OpenMobSelectPayload(List<String> availableMobIds) implements CustomPayload {

    public static final CustomPayload.Id<OpenMobSelectPayload> ID =
            new CustomPayload.Id<>(Identifier.of(SpawnerMod.MOD_ID, "open_mob_select"));

    public static final PacketCodec<RegistryByteBuf, OpenMobSelectPayload> CODEC =
            PacketCodec.tuple(
                    PacketCodecs.STRING.collect(PacketCodecs.toList()), OpenMobSelectPayload::availableMobIds,
                    OpenMobSelectPayload::new
            );

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}