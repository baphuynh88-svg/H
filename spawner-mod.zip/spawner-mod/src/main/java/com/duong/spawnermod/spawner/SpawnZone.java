package com.duong.spawnermod.spawner;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.List;
import java.util.UUID;

/**
 * A persistent spawn zone: a box between pointA and pointB where the given
 * mobs are allowed to naturally spawn on a timer, on top of vanilla spawning
 * elsewhere. Immutable - "editing" a zone means replacing it in SpawnZoneState.
 */
public record SpawnZone(
        UUID id,
        RegistryKey<World> dimension,
        BlockPos pointA,
        BlockPos pointB,
        List<String> mobIds // SpawnableMob enum names
) {

    public static final Codec<SpawnZone> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            com.mojang.serialization.Codec.STRING.xmap(UUID::fromString, UUID::toString)
                    .fieldOf("id").forGetter(SpawnZone::id),
            RegistryKey.createCodec(net.minecraft.registry.RegistryKeys.WORLD)
                    .fieldOf("dimension").forGetter(SpawnZone::dimension),
            BlockPos.CODEC.fieldOf("point_a").forGetter(SpawnZone::pointA),
            BlockPos.CODEC.fieldOf("point_b").forGetter(SpawnZone::pointB),
            com.mojang.serialization.Codec.STRING.listOf().fieldOf("mob_ids").forGetter(SpawnZone::mobIds)
    ).apply(instance, SpawnZone::new));

    /** Minimum corner of the box (inclusive). */
    public BlockPos min() {
        return new BlockPos(
                Math.min(pointA.getX(), pointB.getX()),
                Math.min(pointA.getY(), pointB.getY()),
                Math.min(pointA.getZ(), pointB.getZ())
        );
    }

    /** Maximum corner of the box (inclusive). */
    public BlockPos max() {
        return new BlockPos(
                Math.max(pointA.getX(), pointB.getX()),
                Math.max(pointA.getY(), pointB.getY()),
                Math.max(pointA.getZ(), pointB.getZ())
        );
    }

    public List<SpawnableMob> resolveMobs() {
        return mobIds.stream()
                .map(id -> {
                    try {
                        return SpawnableMob.valueOf(id);
                    } catch (IllegalArgumentException e) {
                        return null;
                    }
                })
                .filter(m -> m != null)
                .toList();
    }
}
