package com.duong.spawnermod.spawner;

import com.duong.spawnermod.network.ConfirmMobSelectionPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class ConfirmMobSelectionHandler {

    private ConfirmMobSelectionHandler() {
    }

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(ConfirmMobSelectionPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();

            SpawnSelectionState.Selection selection =
                    player.getAttachedOrGet(SpawnSelectionState.SELECTION, () -> SpawnSelectionState.Selection.EMPTY);

            if (!selection.isComplete()) {
                player.sendMessage(
                        Text.literal("Selection đã bị hủy hoặc hết hạn, thử lại từ đầu.").formatted(Formatting.RED),
                        false
                );
                return;
            }

            SpawnableMob mob;
            try {
                mob = SpawnableMob.valueOf(payload.mobId());
            } catch (IllegalArgumentException e) {
                player.sendMessage(
                        Text.literal("Mob không hợp lệ.").formatted(Formatting.RED),
                        false
                );
                return;
            }

            if (!mob.isAvailableAt(player.getWorld(), selection.pointA())) {
                player.sendMessage(
                        Text.literal("Vị trí này không còn thỏa điều kiện biome cho " + mob.displayName + ".")
                                .formatted(Formatting.RED),
                        false
                );
                return;
            }

            player.sendMessage(
                    Text.literal("Đã xác nhận: " + mob.displayName + " sẽ spawn trong vùng A="
                            + formatPos(selection.pointA()) + " B=" + formatPos(selection.pointB())
                            + " (Spawn zone thật + tick sẽ làm ở bước tiếp theo)")
                            .formatted(Formatting.GREEN),
                    false
            );

            player.removeAttached(SpawnSelectionState.SELECTION);
        });
    }

    private static String formatPos(net.minecraft.util.math.BlockPos pos) {
        return pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }
}