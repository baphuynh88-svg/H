package com.duong.spawnermod.spawner;

import com.duong.spawnermod.network.ConfirmMobSelectionPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/**
 * Handles ConfirmMobSelectionPayload on the server: re-validates everything
 * (selection still present+complete, each mob id is real, biome requirement
 * still satisfied for each) rather than trusting the client's packet blindly.
 *
 * THIS STEP ONLY: just confirms back to the player which mobs + zone would be
 * used. Actually creating the persistent spawn zone and the tick-based
 * spawning loop is a separate step (PersistentState + server tick handler),
 * not implemented yet.
 */
public final class ConfirmMobSelectionHandler {

    private ConfirmMobSelectionHandler() {
    }

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(ConfirmMobSelectionPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();

            // Re-fetch selection fresh on the server - never trust client-sent positions.
            SpawnSelectionState.Selection selection =
                    player.getAttachedOrGet(SpawnSelectionState.SELECTION, () -> SpawnSelectionState.Selection.EMPTY);

            if (!selection.isComplete()) {
                player.sendMessage(
                        Text.literal("Selection đã bị hủy hoặc hết hạn, thử lại từ đầu.").formatted(Formatting.RED),
                        false
                );
                return;
            }

            if (payload.mobIds().isEmpty()) {
                player.sendMessage(
                        Text.literal("Chưa chọn quái nào.").formatted(Formatting.RED),
                        false
                );
                return;
            }

            List<SpawnableMob> validMobs = new ArrayList<>();
            for (String mobId : payload.mobIds()) {
                SpawnableMob mob;
                try {
                    mob = SpawnableMob.valueOf(mobId);
                } catch (IllegalArgumentException e) {
                    continue; // skip unknown ids rather than failing the whole confirm
                }

                if (mob.isAvailableAt(player.getEntityWorld(), selection.pointA())) {
                    validMobs.add(mob);
                }
            }

            if (validMobs.isEmpty()) {
                player.sendMessage(
                        Text.literal("Không có quái nào hợp lệ (biome không còn thỏa điều kiện).")
                                .formatted(Formatting.RED),
                        false
                );
                return;
            }

            String mobNames = validMobs.stream().map(m -> m.displayName).reduce((a, b) -> a + ", " + b).orElse("");

            SpawnZone zone = new SpawnZone(
                    java.util.UUID.randomUUID(),
                    player.getEntityWorld().getRegistryKey(),
                    selection.pointA(),
                    selection.pointB(),
                    validMobs.stream().map(SpawnableMob::name).toList()
            );

            SpawnZoneState.get(player.getServer()).addZone(zone);

            player.sendMessage(
                    Text.literal("Đã tạo spawn zone: [" + mobNames + "] sẽ random spawn trong vùng A="
                            + formatPos(selection.pointA()) + " B=" + formatPos(selection.pointB()))
                            .formatted(Formatting.GREEN),
                    false
            );

            player.removeAttached(SpawnSelectionState.SELECTION);
        });
    }

    private static String formatPos(net.minecraft.util.math.BlockPos pos) {
        return pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }
}
