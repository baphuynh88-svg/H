package com.duong.spawnermod.spawner;

import net.minecraft.block.Blocks;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;

public final class BiomeRequirement {

    private final RegistryKey<Biome> requiredBiome;

    private BiomeRequirement(RegistryKey<Biome> requiredBiome) {
        this.requiredBiome = requiredBiome;
    }

    public static BiomeRequirement of(RegistryKey<Biome> biome) {
        return new BiomeRequirement(biome);
    }

    public boolean isSatisfiedAt(World world, BlockPos pos) {
        boolean biomeMatches = world.getBiome(pos).matchesKey(requiredBiome);
        if (biomeMatches) {
            return true;
        }
        return fallbackBlockCheck(world, pos);
    }

    private boolean fallbackBlockCheck(World world, BlockPos pos) {
        boolean isNetherWastes = requiredBiome.equals(net.minecraft.world.biome.BiomeKeys.NETHER_WASTES);
        boolean isSoulSandValley = requiredBiome.equals(net.minecraft.world.biome.BiomeKeys.SOUL_SAND_VALLEY);

        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                for (int dy = -2; dy <= 0; dy++) {
                    BlockPos check = pos.add(dx, dy, dz);
                    var state = world.getBlockState(check);

                    if (isNetherWastes && state.isOf(Blocks.NETHERRACK)) {
                        return true;
                    }
                    if (isSoulSandValley && (state.isOf(Blocks.SOUL_SAND) || state.isOf(Blocks.SOUL_SOIL))) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
}