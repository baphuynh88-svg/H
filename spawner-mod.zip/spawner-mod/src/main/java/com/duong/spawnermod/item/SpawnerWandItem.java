package com.duong.spawnermod.item;

import com.duong.spawnermod.spawner.SpawnPositionValidator;
import com.duong.spawnermod.spawner.SpawnSelectionState;
import com.duong.spawnermod.spawner.SpawnSelectionState.Selection;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * The Spawner wand. Right-click a block to pick point A, right-click another
 * block to pick point B. Each click validates the position first (see
 * SpawnPositionValidator) - if invalid, the player gets an action bar message
 * and nothing is selected.
 *
 * Once both points are picked, the player is expected to open the mob-select
 * GUI (not implemented yet in this step) and confirm with /ok or cancel with
 * /no - selection state itself is stored per-player in SpawnSelectionState.
 */
public class SpawnerWandItem extends Item {

    public SpawnerWandItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        if (world.isClient()) {
            // Let the server be the source of truth for selection state; client
            // just swings the arm normally.
            return ActionResult.SUCCESS;
        }

        if (!(context.getPlayer() instanceof ServerPlayerEntity player)) {
            return ActionResult.PASS;
        }

        // The block that was actually clicked - the mob would stand ON TOP of this,
        // so the "spawn position" is one block above the clicked block, unless the
        // clicked block itself is tall/passable (kept simple: always one-above for now).
        BlockPos clickedBlock = context.getBlockPos();
        BlockPos spawnPos = clickedBlock.up();

        if (!SpawnPositionValidator.isValidSpawnPosition(world, spawnPos)) {
            player.sendMessage(
                    Text.literal("Vị trí này không hợp lệ để quái đứng (kiểm tra phiến/cửa sập/hố).")
                            .formatted(Formatting.RED),
                    true
            );
            return ActionResult.FAIL;
        }

        Selection current = player.getAttachedOrGet(SpawnSelectionState.SELECTION, () -> Selection.EMPTY);

        if (current.pointA() == null) {
            player.setAttached(SpawnSelectionState.SELECTION, current.withPointA(spawnPos));
            player.sendMessage(
                    Text.literal("Điểm A đã đặt tại " + formatPos(spawnPos) + ". Click điểm B tiếp theo.")
                            .formatted(Formatting.GREEN),
                    true
            );
            return ActionResult.SUCCESS;
        }

        if (current.pointB() == null) {
            Selection updated = current.withPointB(spawnPos);
            player.setAttached(SpawnSelectionState.SELECTION, updated);
            player.sendMessage(
                    Text.literal("Điểm B đã đặt tại " + formatPos(spawnPos) + ". Gõ /ok để xác nhận hoặc /no để hủy.")
                            .formatted(Formatting.GREEN),
                    true
            );
            return ActionResult.SUCCESS;
        }

        // Both points already set and not yet confirmed/cancelled - remind the player
        // instead of silently overwriting their selection.
        player.sendMessage(
                Text.literal("Đã chọn đủ 2 điểm. Gõ /ok để xác nhận hoặc /no để chọn lại.")
                        .formatted(Formatting.YELLOW),
                true
        );
        return ActionResult.SUCCESS;
    }

    private static String formatPos(BlockPos pos) {
        return pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }
}
