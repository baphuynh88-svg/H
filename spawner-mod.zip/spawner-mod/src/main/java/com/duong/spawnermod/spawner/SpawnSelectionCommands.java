package com.duong.spawnermod.spawner;

import com.duong.spawnermod.network.OpenMobSelectPayload;
import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.stream.Collectors;

public final class SpawnSelectionCommands {

    private SpawnSelectionCommands() {
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("ok").executes(SpawnSelectionCommands::confirm));
        dispatcher.register(CommandManager.literal("no").executes(SpawnSelectionCommands::cancel));
    }

    private static int confirm(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity player = ctx.getSource().getPlayer();
        if (player == null) {
            return 0;
        }

        SpawnSelectionState.Selection selection =
                player.getAttachedOrGet(SpawnSelectionState.SELECTION, () -> SpawnSelectionState.Selection.EMPTY);

        if (!selection.isComplete()) {
            player.sendMessage(
                    Text.literal("Chưa chọn đủ 2 điểm A và B.").formatted(Formatting.RED),
                    false
            );
            return 0;
        }

        List<String> availableMobIds = SpawnableMob.all().stream()
                .filter(mob -> mob.isAvailableAt(player.getWorld(), selection.pointA()))
                .map(Enum::name)
                .collect(Collectors.toList());

        ServerPlayNetworking.send(player, new OpenMobSelectPayload(availableMobIds));

        player.sendMessage(
                Text.literal("Đã xác nhận vùng: A=" + formatPos(selection.pointA())
                        + " B=" + formatPos(selection.pointB()) + ". Chọn quái trong menu vừa mở.")
                        .formatted(Formatting.AQUA),
                false
        );

        return 1;
    }

    private static String formatPos(net.minecraft.util.math.BlockPos pos) {
        return pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }

    private static int cancel(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity player = ctx.getSource().getPlayer();
        if (player == null) {
            return 0;
        }

        player.removeAttached(SpawnSelectionState.SELECTION);
        player.sendMessage(
                Text.literal("Đã hủy chọn điểm.").formatted(Formatting.GRAY),
                false
        );
        return 1;
    }
}