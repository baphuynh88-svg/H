package com.duong.spawnermod.spawner;

import com.duong.spawnermod.network.OpenMobSelectPayload;
import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.stream.Collectors;

public final class SpawnSelectionCommands {

    private SpawnSelectionCommands() {
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("ok").executes(SpawnSelectionCommands::confirm));
        dispatcher.register(CommandManager.literal("no").executes(SpawnSelectionCommands::cancel));
        dispatcher.register(CommandManager.literal("pause").executes(SpawnSelectionCommands::pause));
        dispatcher.register(CommandManager.literal("showzones").executes(SpawnSelectionCommands::showZones));
    }

    private static int confirm(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity player = ctx.getSource().getPlayer();
        if (player == null) {
            return 0;
        }

        SpawnSelectionState.Selection selection =
                player.getAttachedOrGet(SpawnSelectionState.SELECTION, () -> SpawnSelectionState.Selection.EMPTY);

        if (!selection.isComplete()) {
            player.sendMessage(
                    Text.literal("Chưa chọn đủ 2 điểm A và B.").formatted(Formatting.RED),
                    false
            );
            return 0;
        }

        List<String> availableMobIds = SpawnableMob.all().stream()
                .filter(mob -> mob.isAvailableAt(player.getEntityWorld(), selection.pointA()))
                .map(Enum::name)
                .collect(Collectors.toList());

        ServerPlayNetworking.send(player, new OpenMobSelectPayload(availableMobIds));

        player.sendMessage(
                Text.literal("Đã xác nhận vùng: A=" + formatPos(selection.pointA())
                        + " B=" + formatPos(selection.pointB()) + ". Chọn quái trong menu vừa mở.")
                        .formatted(Formatting.AQUA),
                false
        );

        return 1;
    }

    private static String formatPos(net.minecraft.util.math.BlockPos pos) {
        return pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }

    /**
     * /no - if the player has an in-progress A/B selection (not yet confirmed
     * with /ok), cancel just that selection. Otherwise, if the player is
     * standing inside an already-confirmed zone, delete that zone entirely
     * (fully removes it, unlike /pause which just stops it temporarily).
     */
    private static int cancel(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity player = ctx.getSource().getPlayer();
        if (player == null) {
            return 0;
        }

        SpawnSelectionState.Selection selection =
                player.getAttachedOrGet(SpawnSelectionState.SELECTION, () -> SpawnSelectionState.Selection.EMPTY);

        if (selection.pointA() != null || selection.pointB() != null) {
            player.removeAttached(SpawnSelectionState.SELECTION);
            player.sendMessage(
                    Text.literal("Đã hủy chọn điểm.").formatted(Formatting.GRAY),
                    false
            );
            return 1;
        }

        SpawnZoneState state = SpawnZoneState.get(player.getEntityWorld().getServer());
        SpawnZone zone = state.findZoneAt(player.getEntityWorld().getRegistryKey(), player.getBlockPos());

        if (zone == null) {
            player.sendMessage(
                    Text.literal("Không có gì để hủy - bạn không đang chọn điểm, và không đứng trong vùng spawn nào.")
                            .formatted(Formatting.RED),
                    false
            );
            return 0;
        }

        state.removeZone(zone.id());
        player.sendMessage(
                Text.literal("Đã xóa hoàn toàn vùng spawn tại A=" + formatPos(zone.pointA())
                        + " B=" + formatPos(zone.pointB()) + ".")
                        .formatted(Formatting.GRAY),
                false
        );
        return 1;
    }

    /**
     * /pause - toggles pause/resume for the confirmed zone the player is
     * currently standing inside. A paused zone stays saved but stops
     * spawning until /pause is used again in it.
     */
    private static int pause(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity player = ctx.getSource().getPlayer();
        if (player == null) {
            return 0;
        }

        SpawnZoneState state = SpawnZoneState.get(player.getEntityWorld().getServer());
        SpawnZone zone = state.findZoneAt(player.getEntityWorld().getRegistryKey(), player.getBlockPos());

        if (zone == null) {
            player.sendMessage(
                    Text.literal("Bạn không đứng trong vùng spawn nào. Đứng vào giữa A và B rồi thử lại.")
                            .formatted(Formatting.RED),
                    false
            );
            return 0;
        }

        SpawnZone updated = zone.withPaused(!zone.paused());
        state.replaceZone(updated);

        if (updated.paused()) {
            player.sendMessage(
                    Text.literal("Đã tạm dừng vùng spawn (A=" + formatPos(zone.pointA())
                            + " B=" + formatPos(zone.pointB()) + "). Gõ /pause lại trong vùng này để tiếp tục.")
                            .formatted(Formatting.YELLOW),
                    false
            );
        } else {
            player.sendMessage(
                    Text.literal("Đã tiếp tục vùng spawn (A=" + formatPos(zone.pointA())
                            + " B=" + formatPos(zone.pointB()) + ").")
                            .formatted(Formatting.GREEN),
                    false
            );
        }
        return 1;
    }

    /**
     * /showzones - spawns a short-lived particle outline around every
     * confirmed zone in the player's current dimension, so the box is easy
     * to see in the world. Purely visual, does not change any state.
     */
    private static int showZones(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity player = ctx.getSource().getPlayer();
        if (player == null) {
            return 0;
        }

        SpawnZoneState state = SpawnZoneState.get(player.getEntityWorld().getServer());
        java.util.List<SpawnZone> zones = state.getZones().stream()
                .filter(z -> z.dimension().equals(player.getEntityWorld().getRegistryKey()))
                .toList();

        if (zones.isEmpty()) {
            player.sendMessage(
                    Text.literal("Chưa có vùng spawn nào trong thế giới này.").formatted(Formatting.GRAY),
                    false
            );
            return 0;
        }

        for (SpawnZone zone : zones) {
            SpawnZoneOutline.show(player.getEntityWorld(), zone, player, zone.paused());
        }

        player.sendMessage(
                Text.literal("Đang hiện viền " + zones.size() + " vùng spawn (giữ khoảng vài giây).")
                        .formatted(Formatting.AQUA),
                false
        );
        return 1;
    }
}