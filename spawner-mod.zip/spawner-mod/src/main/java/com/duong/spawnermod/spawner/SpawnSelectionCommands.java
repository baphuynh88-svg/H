package com.duong.spawnermod.spawner;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Registers /ok and /no for confirming or cancelling the current Spawner wand
 * point A / point B selection.
 *
 * Current behavior (this step only):
 *   /ok  - if both points are selected, prints them and clears the selection.
 *          (Actually creating a persistent spawn zone + the mob-select GUI
 *          come in a later step - not implemented yet.)
 *   /no  - clears the selection regardless of how many points were picked.
 */
public final class SpawnSelectionCommands {

    private SpawnSelectionCommands() {
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("ok").executes(SpawnSelectionCommands::confirm));
        dispatcher.register(CommandManager.literal("no").executes(SpawnSelectionCommands::cancel));
    }

    private static int confirm(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity player = ctx.getSource().getPlayer();
        if (player == null) {
            return 0;
        }

        SpawnSelectionState.Selection selection =
                player.getAttachedOrGet(SpawnSelectionState.SELECTION, () -> SpawnSelectionState.Selection.EMPTY);

        if (!selection.isComplete()) {
            player.sendMessage(
                    Text.literal("Chưa chọn đủ 2 điểm A và B.").formatted(Formatting.RED),
                    false
            );
            return 0;
        }

        player.sendMessage(
                Text.literal("Đã xác nhận vùng: A=" + selection.pointA() + " B=" + selection.pointB()
                        + " (Mob select GUI + spawn zone sẽ làm ở bước tiếp theo)")
                        .formatted(Formatting.AQUA),
                false
        );

        player.removeAttached(SpawnSelectionState.SELECTION);
        return 1;
    }

    private static int cancel(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        ServerPlayerEntity player = ctx.getSource().getPlayer();
        if (player == null) {
            return 0;
        }

        player.removeAttached(SpawnSelectionState.SELECTION);
        player.sendMessage(
                Text.literal("Đã hủy chọn điểm.").formatted(Formatting.GRAY),
                false
        );
        return 1;
    }
}
