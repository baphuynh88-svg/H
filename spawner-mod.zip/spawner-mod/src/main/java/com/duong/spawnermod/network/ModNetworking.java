package com.duong.spawnermod.network;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;

public final class ModNetworking {

    private ModNetworking() {
    }

    public static void registerCommon() {
        PayloadTypeRegistry.playS2C().register(OpenMobSelectPayload.ID, OpenMobSelectPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ConfirmMobSelectionPayload.ID, ConfirmMobSelectionPayload.CODEC);
    }
}