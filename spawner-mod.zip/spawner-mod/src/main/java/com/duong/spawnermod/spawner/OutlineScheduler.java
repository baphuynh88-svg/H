package com.duong.spawnermod.spawner;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import java.util.ArrayList;
import java.util.List;

/**
 * Minimal delayed-task runner driven off the server tick event. Only used by
 * SpawnZoneOutline to spread particle bursts out over a few seconds - not a
 * general-purpose scheduler, just enough for that one job.
 */
final class OutlineScheduler {

    private record Task(long dueAtTick, Runnable action) {
    }

    private static final List<Task> tasks = new ArrayList<>();
    private static long currentTick = 0;
    private static boolean registered = false;

    private OutlineScheduler() {
    }

    static void runAfter(long delayTicks, Runnable action) {
        ensureRegistered();
        tasks.add(new Task(currentTick + delayTicks, action));
    }

    private static void ensureRegistered() {
        if (registered) {
            return;
        }
        registered = true;
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            currentTick++;
            if (tasks.isEmpty()) {
                return;
            }
            List<Task> due = new ArrayList<>();
            for (Task task : tasks) {
                if (task.dueAtTick() <= currentTick) {
                    due.add(task);
                }
            }
            tasks.removeAll(due);
            for (Task task : due) {
                task.action().run();
            }
        });
    }
}
