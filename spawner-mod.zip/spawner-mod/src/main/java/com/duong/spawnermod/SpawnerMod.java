package com.duong.spawnermod;

import com.duong.spawnermod.item.ModItems;
import com.duong.spawnermod.network.ModNetworking;
import com.duong.spawnermod.spawner.ConfirmMobSelectionHandler;
import com.duong.spawnermod.spawner.SpawnSelectionCommands;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SpawnerMod implements ModInitializer {

    public static final String MOD_ID = "spawnermod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.initialize();

        ModNetworking.registerCommon();
        ConfirmMobSelectionHandler.register();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                SpawnSelectionCommands.register(dispatcher));

        LOGGER.info("Spawner Wand mod initialized");
    }
}