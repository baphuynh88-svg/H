package com.duong.spawnermod.spawner;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Identifier;

/**
 * Holds the in-progress point A / point B selection for a player using the
 * Spawner wand. Not persistent and not synced - this is short-lived UI state,
 * cleared as soon as the player confirms (/ok) or cancels (/no), or logs out.
 */
public final class SpawnSelectionState {

    public static final AttachmentType<Selection> SELECTION = AttachmentRegistry.create(
            Identifier.of("spawnermod", "spawn_selection")
    );

    private SpawnSelectionState() {
    }

    /**
     * Immutable snapshot of the player's current point A / point B selection.
     * Either point may be null if not yet picked.
     */
    public record Selection(BlockPos pointA, BlockPos pointB) {

        public static final Selection EMPTY = new Selection(null, null);

        public Selection withPointA(BlockPos pos) {
            return new Selection(pos, this.pointB);
        }

        public Selection withPointB(BlockPos pos) {
            return new Selection(this.pointA, pos);
        }

        public boolean isComplete() {
            return pointA != null && pointB != null;
        }
    }
}